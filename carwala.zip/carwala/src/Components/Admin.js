import axios from 'axios'
import React, { useEffect, useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Table } from 'react-bootstrap';
import AddCar from './AddCar';
import EditCar from './EditCar';
import DeleteCar from './DeleteCar';
import Login from './Login';
import './Admin.css';
function Admin() {


 const [cardetails, setcardetails] = useState([]);
 const [showAddModal, setshowAddModal] = useState(false);
  const [showEditModal, setshowEditModal] = useState(false); 
   const [selectedCar, setselectedCar] = useState({});
   const [showdeleteModal, setshowdeleteModal] = useState(false);
  useEffect(() => {
   
    seeAllCar();
  
   
 },[])



 

 let hidedeleteModal=()=>{

   setshowdeleteModal(false);
 }
  let hideAddModal=()=>{
    setshowAddModal(false);
  }
  let hideEditModal=()=>{
    setshowEditModal(false);
  }
  let setShowEditModalFunction=(car)=>{
    setshowEditModal(true);
    setselectedCar(car);    
  }

   let setShowDeleteModalFunction=(car)=>{
        setshowdeleteModal(true);
        setselectedCar(car)
   }
let   seeAllCar=async()=>{

  let jwtToken=localStorage.getItem("jwtToken");
   let token=`Bearer ${jwtToken}`
       
    let res=await axios.get("http://localhost:8080/admin/getcarDetails",
    {
      headers:{"Authorization":token}
    });
    if(res.data.error){
      console.log(res.data.msg);

    }
    else{
      console.log(res.data.carlist);
      let fetchedDetails=res.data.carlist;
      setcardetails(fetchedDetails);
      console.log(cardetails);
    }
  }
  
  return (
    <div  className='container'>
      {/* <button onClick={setshowAddModal(true)}
      className='btn btn-primary'>
        Add car

      </button> */}
      <div className='row'>
      
     {
         cardetails.map((car)=>{

            return(
              
 <div className='col-1 col-md-2 col-lg-3 m-4 single-car'>
                  <div className='row'>
                      <img src={car.carImageUrl}/>
                 </div>
                 <div className='row'>
                      <div className='col'>
                        <p> car Name</p>
                    </div>
                      <div className='col'>
                        <p>{car.carName}</p>
                 </div>
                 </div>
                 <div className='row'>
                      <div className='col'>
                        <p>Company</p>
                    </div>
                      <div className='col'>
                        <p>{car.carCompany}</p>
                 </div>
                 </div>
                 <div className='row'>
                      <div className='col'>
                      <button
                      className='btn btn-warning'
                      onClick={()=>{setShowEditModalFunction(car)}}>
                            Edit car

                      </button>   
                    </div>
                      <div className='col'>
                      <button
                      className='btn btn-warning'
                      onClick={()=>{setShowDeleteModalFunction(car)}}>
                            Delete car

                      </button>
                 </div>
                 </div>
              
                
                    
                     
                    

                    
                     
                    
               
                 </div>
                 
                 )
                
         })

       }
       </div>
    
     

     
  
  
           
<AddCar  
showAddModal={showAddModal}
hideAddModal={hideAddModal}/>
   {/* <EditCar
    showEditModal={showEditModal}
    hideEditModal={hideEditModal}
    selectedCar={selectedCar}
   />
   <DeleteCar
       selectedCar={selectedCar}
       showdeleteModal={showdeleteModal}
       hidedeleteModal={hidedeleteModal}
   
   
   /> */}

   
      </div>
   
  )
}

export default Admin;