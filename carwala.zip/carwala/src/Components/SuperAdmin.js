import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Col, Container, Row } from 'react-bootstrap';
import './SuperAdmin.css'
function SuperAdmin() {
  const [carDetails, setcarDetails] = useState([]);
   let adminName=""  

  useEffect(() => {
   
    seeAllCar();

  }, [])
        let seeAllCar=async()=>{
            let jwtToken=localStorage.getItem("jwtToken");
            let token=`Bearer ${jwtToken}`
            let res=await axios.get("http://localhost:8080/superAdmin/getAllCar",{
                headers:{
                    "Authorization":token
                }
            });
            if(res.data.error){
                console.log(res.data.message);
            }
            else{
                console.log(res.data.message);
                console.log(res.data.carlist);
                let fetchedDetails=res.data.carlist;
                setcarDetails(fetchedDetails);
            }
        }

    return (
            <div>
          <Container className='container'>
                         <Row className='row'>
  
           {
               carDetails.map((car)=>{
               
                {adminName=car.adminDetails.userName}
                return(
                  
                             <Col className='col'>
                             
                      <div key={car.carId}>
                    
 
        
                    <p ><span>Admin Name</span> {car.adminDetails.userName}</p>
                    <p><span>car Name</span>   {car.carName}</p>
                     <p><span>car Company</span>  {car.carCompany}</p>  
                     <p><span>Fuel type</span>  {car.fuelType}</p>
                     <p><span>powerSteering</span>  {car.powerSteering}</p>
                     <p><span>seating capacity</span>  {car.seatingCapacity}</p>

                     <p></p>
                     <p> </p>
                       </div>
                       </Col>
                     
                  )                 
                   
               })
               }
               </Row>
               </Container>
            
           
      
           </div>
  
  )
}

export default SuperAdmin