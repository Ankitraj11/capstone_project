import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button, Form, Modal } from 'react-bootstrap';

function EditCar(props) {
   const [selectedCar, setselectedCar] = useState({

        carId:"",
        carCompany:"",
        fuelType:"",
        carName:"",
        powerSteering:"",
        carImageUrl:"",
        breakSystem:"",
        showRoomPrice:"",
        onRoadPrice:"",
        mileage:"",
        seatingCapacity:"",
        engineCapacity:"",
        gearType:""
   });

   let updateCar=async()=>{
       let res=await axios.put(`http://localhost:8080/admin/updateCar/${props.selectedCar.carId}`,selectedCar);
       try{
       if(res.data.error){
           res.data.message
       }
       else{
           res.data.message
           console.log(res.data.message);
       }
    }
    catch(eror){
        console.log(eror);
    }
   }
   useEffect(() => {

   
    setselectedCar(props.selectedCar);
     
   },[props.selectedCar])
   
   let updatecarDetails=(e)=>{
       
       setselectedCar({
           ...selectedCar,
           [e.target.name]:e.target.value,
       })
   }
    return (
    
          <div>
        <Modal show={props.showEditModal} onHide={props.hideEditModal}>
        <Modal.Header closeButton>
          <Modal.Title>Update Car</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Form>
  <Form.Group className="mb-3" controlId="formBasicCarName">
    <Form.Label>Car Name</Form.Label>
    <Form.Control type="text" placeholder="Enter car name"
    name="carName" 
    value={selectedCar.carName} 
    onChange={updatecarDetails}/>
    <Form.Text className="text-muted">
     car Name first letter should be capital
    </Form.Text>
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>Company Name</Form.Label>
    <Form.Control type="text" placeholder="enter company"
     value={selectedCar.carCompany}
     name="carCompany" 
     onChange={updatecarDetails}/>
  </Form.Group>
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>Fuel Type</Form.Label>
    <Form.Control type="text" placeholder="fuel"
     value={selectedCar.fuelType}
     name="fuelType" 
     onChange={updatecarDetails}/>
     <Form.Text className="text-muted">
    type diesel or petrol only in small( ex: diesel)
    </Form.Text>
  </Form.Group>
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>powersteering</Form.Label>
    <Form.Control type="boolean" placeholder="powersteering"
     value={selectedCar.powerSteering}
     name="powerSteering" 
     onChange={updatecarDetails}/>
     <Form.Text className="text-muted">
    type  1 for yes 0 for no only in small( ex: 1)
    </Form.Text>
  </Form.Group>
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>Car image</Form.Label>
    <Form.Control type="text" placeholder="enter image url"
      value={selectedCar.carImageUrl}
      name="carImageUrl"
      onChange={updatecarDetails}/>
  </Form.Group>
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>Break System</Form.Label>
    <Form.Control type="text" placeholder="break System"
      value={selectedCar.breakSystem}
      name="breakSystem"
      onChange={updatecarDetails}/>
       <Form.Text className="text-muted">
    type  manual or automatic only in small( ex: manual)
    </Form.Text>
  </Form.Group>
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>show room price</Form.Label>
    <Form.Control type="number" placeholder="enter showroom price"
     value={selectedCar.showRoomPrice}
     name="showRoomPrice"
     onChange={updatecarDetails} />
  </Form.Group>
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>on Road price</Form.Label>
    <Form.Control type="number" placeholder="enter OnRoad price" 
     value={selectedCar.onRoadPrice}
     name="onRoadPrice"
     onChange={updatecarDetails}/>
  </Form.Group>
 
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>mileage</Form.Label>
    <Form.Control type="number" placeholder="mileage"  
    value={selectedCar.mileage}
    name="mileage"
    onChange={updatecarDetails}/>
  </Form.Group>
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>seating capacity</Form.Label>
    <Form.Control type="number" placeholder="Seating capacity" 
    value={selectedCar.seatingCapacity}
    name="seatingCapacity" 
    onChange={updatecarDetails}/>
  </Form.Group>
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>Engine capacity</Form.Label>
    <Form.Control type="number" placeholder="Engine Capacity"
     value={selectedCar.engineCapacity}
     name="engineCapacity"
     onChange={updatecarDetails} />
  </Form.Group>
  
  
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>gear type</Form.Label>
    <Form.Control type="text" placeholder="gear type"
     value={selectedCar.gearType}
     name="gearType" 
     onChange={updatecarDetails}/>
     <Form.Text className="text-muted">
    type automatic or manual only in small( ex: manual)
    </Form.Text>
  </Form.Group>
 
 
  <Button variant="primary" type="submit">
    Submit
  </Button>
</Form>


        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={props.hideEditModal}>
            Close
          </Button>
          <Button variant="primary" onClick={updateCar}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>




    </div>
  )
}

export default EditCar;