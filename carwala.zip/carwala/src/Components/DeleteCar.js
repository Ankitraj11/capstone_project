import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Button, Modal } from 'react-bootstrap'

function DeleteCar(props) {
const [selectedcar, setselectedcar] = useState({});

  useEffect(() => {

      setselectedcar(props.selectedCar);
  
  }, [props.selectedCar])
  console.log(selectedcar);
  
let deletecar=async()=>{

  let res=await axios.delete(`http://localhost:8080/deleteCar/${selectedcar.carId}`);
  try{
  if(res.data.error){
    console.log(res.data.message);
  }
  else{
    console.log(res.data.message);
  }
}
catch(error){
console.log(error);
}
}
  return (
    <div>
<Modal show={props.showdeleteModal} onHide={props.hidedeleteModal}>
        <Modal.Header closeButton>
          <Modal.Title>DeleteCar</Modal.Title>
        </Modal.Header>
        <Modal.Body>
               are you sure want to delete {props.selectedCar.carName}?
              </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={props.hidedeleteModal}>
            Close
          </Button>
          <Button variant="primary" onClick={deletecar}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>

        
    </div>
  )
}

export default DeleteCar