import axios from 'axios';
import React, { useState } from 'react'
import "./Registration.css"
function Registration() {
  const [userDetails, setuserDetails] = useState({
      userName:"",
      password:"",
      adminRole:"",
  })

  let updateUserDetails=(e)=>{
      
    setuserDetails({
        ...userDetails,
        [e.target.name]:e.target.value,
    });
  }
  let register=async()=>{
            let res=await axios.post("http://localhost:8080/admin/signUp",userDetails);
           try{

            if(res.data.error){
               
               console.log( res.data.message);
            }
            else{
               console.log( res.data.message);
            }
        }catch(error){
            console.log(error);
        }

  }
    return (
    <div>

<form className="form-inline register-form">
        <div className="form-group mx-sm-3 mb-2">
          <label htmlFor="username" className="sr-only">User Name</label>
          <input type="text" 
          onChange={updateUserDetails}
          name="userName"
          value={userDetails.userName}
          className="form-control" placeholder='username' id="username"  />
        </div>
        <div className="form-group mx-sm-3 mb-2">
          <label htmlFor="password" className="sr-only">Password</label>
          <input type="password" 
          value={userDetails.password}
          name="password"
          onChange={updateUserDetails}
          className="form-control" id="password" placeholder="Password" />
        </div>
        <div className="form-group mx-sm-3 mb-2">
          <label htmlFor="userRole" className="sr-only">UserRole</label>
          <input type="text" 
          value={userDetails.userRole}
          name="userRole"
          className="form-control" id="userRole" placeholder="UserRole" />
        </div>
        <button type="submit" onClick={register} className="btn btn-primary mb-2">Register</button>
      </form>
   





    </div>
  )
}

export default Registration;