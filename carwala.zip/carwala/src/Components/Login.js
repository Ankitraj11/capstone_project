import axios from 'axios'
import React, { useState } from 'react'
import { withRouter } from 'react-router-dom';
import "./Login.css"
function Login(props) {
    const [userDetails, setuserDetails] = useState({
   
        username:"",
        password:"",
    })
    console.log(userDetails);
  
    let login=async()=>{
    let errorMsg="";
    let error="";
       
         if(Object.keys(error).length==0){
            let res=await axios.post("http://localhost:8080/admin/loggedIn",userDetails);
            if(res.data.error){
               errorMsg=res.data.message;
               alert(errorMsg);
            }
            else{
                console.log(res.data.userRoles[0].authority);
                console.log(res.data.token);
                console.log(res.data.userRoles);
                console.log(res.data.message);
                localStorage.setItem("jwtToken",res.data.token);
                localStorage.setItem("roles",res.data.userRoles[0].authority);
                
                let role=localStorage.getItem("roles");
                if(role=="ROLE_ADMIN"){
                    props.history.push("/admin");
                }
                else if(role=="ROLE_SUPERADMIN"){
                    props.history.push("/superAdmin");
                }

            }
         

     }
  

    }
    let updateuserDetails=(e)=>{
                setuserDetails({
                    ...userDetails,
                   [e.target.name]:e.target.value,

                })

    }
  return (
    <div>
      
         <div className="form-group login-form">
          <label htmlFor="userName" className="label">User Name</label>
          <input type="text" className="form-control"
          name="username"
          value={userDetails.username}
          onChange={updateuserDetails} 
           aria-describedby="userNameHelp" 
           placeholder="Enter username" />
          <small id="userNameHelp" 
          className="form-text text-muted text-muted-color">
              We'll never share your email with anyone else.</small>
        
        <div className="form-group">
          <label className="label"htmlFor="password">Password</label>
          <input type="password" 
          name="password"
            onChange={updateuserDetails}
            value={userDetails.password}
          className="form-control" 
          placeholder="Password" />
        </div>
      
        <button type="submit"
         onClick={login}
          className="btn btn-primary">Login</button>
     
     
       </div>
     
     


    </div>
  )
}

export default withRouter(Login)