import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Button, Modal } from 'react-bootstrap'

function DeleteCar(props) {
const [selectedcar, setselectedcar] = useState({});

  useEffect(() => {

      setselectedcar(props.selectedCar);
  
  }, [props.selectedCar])
  console.log(selectedcar);
  
let deletecar=async()=>{
   let jwtToken=localStorage.getItem("jwtToken");
   let token=`Bearer ${jwtToken}`
  let res=await axios.delete(`http://localhost:8080/admin/deleteCar/${selectedcar.carId}`,{
    headers:{
      "Authorization":token
    }
  });
      
  try{
  if(res.data.error){
    console.log(res.data.msg);
     alert(res.data.msg);
  }
  else{
    console.log(res.data.msg);
    alert(res.data.msg);
    props.hidedeleteModal();
  }
}
catch(error){
console.log(error);
}
}
  return (
    <div>
<Modal show={props.showdeleteModal} onHide={props.hidedeleteModal}>
        <Modal.Header closeButton>
          <Modal.Title>DeleteCar</Modal.Title>
        </Modal.Header>
        <Modal.Body>
               are you sure want to delete {props.selectedCar.carName}?
              </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={props.hidedeleteModal}>
            Close
          </Button>
          <Button variant="primary" onClick={deletecar}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>

        
    </div>
  )
}

export default DeleteCar