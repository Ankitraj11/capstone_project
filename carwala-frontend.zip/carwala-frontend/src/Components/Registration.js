import axios from 'axios';
import React, { useState } from 'react'
import "./Registration.css"
function Registration() {
  const [userDetails, setuserDetails] = useState({
    userName: "",
    password: "",
    adminRole: "",
  })
  let res = "";
  console.log(userDetails);
  let updateUserDetails = (e) => {

    setuserDetails({
      ...userDetails,
      [e.target.name]: e.target.value,
    });
  }
  let submit = (event) => {

    event.preventDefault();
  }




  let register = async () => {



    if (userDetails.adminRole === "ROLE_ADMIN") {

      


        res = await axios.post("http://localhost:8080/admin/signUp", userDetails);
    }
      else {
        res = await axios.post("http://localhost:8080/superAdmin/signUp", userDetails);
      }
      try {

        if (res.data.error) {

          console.log(res.data.message);
          alert(res.data.message);

        }
        else {
          console.log(res.data.message);
          alert(res.data.message);
        }
      } catch (error) {
        console.log(error);
      }
    }
  



  return (
    <div>

      <form className="form-inline register-form " onSubmit={submit}>
        <div className="form-group mx-sm-3 mb-2">
          <label htmlFor="username" className="sr-only">User Name</label>
          <input type="text"
            onChange={updateUserDetails}
            name="userName"
            value={userDetails.userName}
            className="form-control" placeholder='username' id="username" />
          <span id='nameError'></span>
        </div>
        <div className="form-group mx-sm-3 mb-2">
          <label htmlFor="password" className="sr-only">Password</label>
          <input type="password"
            value={userDetails.password}
            name="password"
            onChange={updateUserDetails}
            className="form-control" id="password" placeholder="Password" />
        </div>
        <div className="form-group mx-sm-3 mb-2">
          <select className="custom-select" name="adminRole" onChange={updateUserDetails}>
            <option selected>Choose your role</option>
            <option value="ROLE_ADMIN" name="admin">Admin</option>
            <option value="ROLE_SUPERADMIN" name="superAdmin">Super Admin</option>

          </select>
        </div>
        <button type="submit" onClick={register} className="btn btn-primary mb-2">Register</button>
      </form>






    </div>
  )

  }

export default Registration;