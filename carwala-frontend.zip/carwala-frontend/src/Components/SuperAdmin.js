import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Col, Container, Row } from 'react-bootstrap';
import './SuperAdmin.css'
function SuperAdmin() {
  const [carDetails, setcarDetails] = useState([]);
   let adminName=""  
    let powerSteeringvalue;
  useEffect(() => {
   
    seeAllCar();

  }, [])
        let seeAllCar=async()=>{
            let jwtToken=localStorage.getItem("jwtToken");
            let token=`Bearer ${jwtToken}`
            let res=await axios.get("http://localhost:8080/superAdmin/getAllCar",{
                headers:{
                    "Authorization":token
                }
            });
            if(res.data.error){
                console.log(res.data.message);
            }
            else{
                console.log(res.data.message);
                console.log(res.data.carlist);
                let fetchedDetails=res.data.carlist;
                setcarDetails(fetchedDetails);
            }
        }

    return (
            <div>
          <Container className='superAdmin'>
                       
                 <div className='d-flex flex-wrap'>
           {
               carDetails.map((car)=>{
                    
                {adminName=car.adminDetails.userName}
                return(
                       
                           
                       

                      <div className='p-2 super-admin-car' key={car.carId}>
                                  {   powerSteeringvalue=car.powerSteering 
                                        
                                 }         
                       
                        <div className='row'>
                          <div className='col'>
                            <img src={car.carImageUrl}
                            width="250px"
                            />
                            </div>
                     <div className='col'>Admin Name</div>
                     <div className='col'> {car.adminDetails.userName}</div>
                       </div> 
                       <div className='row'>  
                     <div className='col'>car Name</div> 
                     <div className='col'>  {car.carName}</div>
                      <div className='col'> car Company </div>
                       <div className='col'> {car.carCompany}</div>
                       </div>
                       <div className='row'> 
                           
                     <div className='col'>Fuel Type</div>
                     <div className='col'>{car.fuelType}</div>
                     <div className='col'>powerSteering</div>  
                     <div className='col'>{car.powerSteering}</div>
                     </div>
                     <div className='row'>
                     <div className='col'>seating capacity </div>
                     <div className='col'> {car.seatingCapacity}</div>
                     <div className='col'>Show Room Price</div>
                     <div className='col'>{car.showRoomPrice}</div>
                     </div>
                     <div className='row'>
                     <div className='col'>On Road Price </div>
                     <div className='col'> {car.onRoadPrice}</div>
                     <div className='col'>Mileage</div>
                     <div className='col'>{car.mileage}</div>
                     </div>
                     <div className='row'>
                     <div className='col'>Engine Capacity </div>
                     <div className='col'> {car.engineCapacity}</div>
                     <div className='col'>Gear Type</div>
                     <div className='col'>{car.gearType}</div>
                     </div>
                    </div>
                       
                     
                  )                 
                   
               })
               }
            </div>
             </Container> 
      </div>
           
  
  )
}

export default SuperAdmin