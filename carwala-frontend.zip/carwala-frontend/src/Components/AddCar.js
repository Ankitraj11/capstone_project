import axios from 'axios';
import React, { useState } from 'react'
import { Button, Form, Modal } from 'react-bootstrap';

function AddCar(props) {
  
  const [singleCar, setsingleCar] = useState({

        carId:"",
        carCompany:"",
        fuelType:"",
        carName:"",
        powerSteering:"",
        carImageUrl:"",
        breakSystem:"",
        showRoomPrice:"",
       
        mileage:"",
        seatingCapacity:"",
        engineCapacity:"",
        gearType:""


  });
  
   let addCarDetails=async()=>{

    let jwtToken=localStorage.getItem("jwtToken");
    let token=`Bearer ${jwtToken}`

    let res=await axios.post("http://localhost:8080/admin/addCar",singleCar,{
      headers: {
        "Authorization":token,
      }
    });
    if(res.data.error){
        console.log(res.data.msg);
        alert(res.data.msg);
    }
    else{
        console.log(res.data.msg);
         alert(res.data.msg);
         props.hideAddModal();
    }
     
   }       

  let updatecarDetails=(e)=>{
          setsingleCar({
              ...singleCar,
              [e.target.name]:e.target.value,
          })
        
  }
  console.log(singleCar);
  
    
  return (
    <div>
        <Modal show={props.showAddModal} onHide={props.hideAddModal}>
        <Modal.Header closeButton>
          <Modal.Title>Add Car</Modal.Title>
        </Modal.Header>
        <Modal.Body>
       
        <Form>
       
  <Form.Group className="mb-3" controlId="formBasicCarName">
    <Form.Label>Car Name</Form.Label>
    <Form.Control type="text" placeholder="Enter car name"
    name="carName" 
    value={singleCar.carName} 
    onChange={updatecarDetails}/>
    <Form.Text className="text-muted">
     car Name first letter should be capital
    </Form.Text>
  </Form.Group>
     
   
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>Company Name</Form.Label>
    <Form.Control type="text" placeholder="enter company"
     value={singleCar.carCompany}
     name="carCompany" 
     onChange={updatecarDetails}/>
  </Form.Group>
  
 
  {/* <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>Fuel Type</Form.Label>
    <Form.Control type="text" placeholder="fuel"
     value={singleCar.fuelType}
     name="fuelType" 
     onChange={updatecarDetails}/>
     <Form.Text className="text-muted">
    type diesel or petrol only in small( ex: diesel)
    </Form.Text>
  </Form.Group> */}
   <select class="custom-select" name="fuelType" onChange={updatecarDetails}>
      
    <option selected>Choose fuel</option>
    <option value="petrol" name="petrol">Petrol</option>
    <option value="diesel" name="diesel">Diesel</option>
    <option value="electric" name="electric">Electric</option>
  </select>
 
  <select class="custom-select mt-2" name="powerSteering"  onChange={updatecarDetails}>
    <option selected>powerSteering</option>
    <option value="true" name="true">YES</option>
    <option value="false" name="false">NO</option>
    
  </select>
  
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>Car image</Form.Label>
    <Form.Control type="text" placeholder="enter image url"
      value={singleCar.carImageUrl}
      name="carImageUrl"
      onChange={updatecarDetails}/>
  </Form.Group>
  
  
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>Break System</Form.Label>
    <Form.Control type="text" placeholder="break System"
      value={singleCar.breakSystem}
      name="breakSystem"
      onChange={updatecarDetails}/>
       <Form.Text className="text-muted">
    type  manual or automatic only in small( ex: manual)
    </Form.Text>
  </Form.Group>
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>show room price</Form.Label>
    <Form.Control type="number" placeholder="enter showroom price"
     value={singleCar.showRoomPrice}
     name="showRoomPrice"
     onChange={updatecarDetails} />
  </Form.Group>
 
 
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>mileage</Form.Label>
    <Form.Control type="number" placeholder="mileage"  
    value={singleCar.mileage}
    name="mileage"
    onChange={updatecarDetails}/>
  </Form.Group>
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>seating capacity</Form.Label>
    <Form.Control type="number" placeholder="Seating capacity" 
    value={singleCar.seatingCapacity}
    name="seatingCapacity" 
    onChange={updatecarDetails}/>
  </Form.Group>
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>Engine capacity</Form.Label>
    <Form.Control type="number" placeholder="Engine Capacity"
     value={singleCar.engineCapacity}
     name="engineCapacity"
     onChange={updatecarDetails} />
  </Form.Group>
  
  
  <Form.Group className="mb-3" controlId="formBasicCarCompany">
    <Form.Label>gear type</Form.Label>
    <Form.Control type="text" placeholder="gear type"
     value={singleCar.gearType}
     name="gearType" 
     onChange={updatecarDetails}/>
     <Form.Text className="text-muted">
    type automatic or manual only in small( ex: manual)
    </Form.Text>
  </Form.Group>
 
 
 
</Form>


        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={props.hideAddModal}>
            Close
          </Button>
          <Button variant="primary" onClick={addCarDetails} >
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>



    </div>
  )
}

export default AddCar;