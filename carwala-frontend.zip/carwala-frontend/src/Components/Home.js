import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Form } from 'react-bootstrap'
import { unstable_renderSubtreeIntoContainer } from 'react-dom';

import "./Home.css"
function Home() {
  
 const [searchInput, setSearchInput] = useState("");
  const [searchType, setSearchType] = useState(""); 
 const [carDetails, setcarDetails] = useState([]);
 let updateSearchType=(e)=>{
      
      setSearchType(e.target.name=e.target.value)
 }
 let res="";
let updateSearchInput=(e)=>{
  setSearchInput(e.target.name=e.target.value);
}
 console.log(searchType);
 console.log(searchInput);
 console.log(carDetails);
 let getCar=async()=>{
     if(searchType==="carName"){

     
       res=await axios.get(`http://localhost:8080/user/getCarByName/${searchInput}`); 
     }
     else if(searchType==="carCompany"){
    res=await axios.get(`http://localhost:8080/user/getCarByCompany/${searchInput}`);
     } 
     else{
      res=await axios.get(`http://localhost:8080/user/getCarByfuelType/${searchInput}`); 
     }
    
      if(res.data.error){
          console.log(res.data.error);
        }
        else{
          console.log(res.data.carDetails);
          let fetchedDetailsByCategory=res.data.carDetails;
          setcarDetails(fetchedDetailsByCategory);
        }
}
  return(

  
        

      <div className='container home'>
           
   
            <h1>welcome to Car Wala application</h1>      
   
   
            <div className="row g-3 align-items-center">
  <div className="col-auto">
  <select  onChange={updateSearchType} 
  className="form-select" aria-label="Default select example">
  <option selected>Search by </option>
  <option value="carName" name="carName">Car Name</option>
  <option value="carCompany" name="carCompany">Car Company</option>
  <option value="fuelType" name="fuelType">Fuel Type</option>
</select>

 
  </div>
  <div className="col-auto">
    <input type="text"  name='searchInput'
     value={searchInput}
    onChange={updateSearchInput} 
    className="form-control" aria-describedby="button"></input>
  </div>
  <div className="col-auto">
    <span id="button" className="form-text">
   
 
    <button onClick={getCar}
    className="btn btn-primary"  >
              Search Car
          </button>
    </span>
  </div>
</div>
      <div className='d-flex flex-wrap'>

     {carDetails.map((car)=>{
        return(
  <div>   <div className=" car-card">
          <div key={car.carId}>
            <div className='d-flex'>
              
              <div>
                <img src={car.carImageUrl} 
                width="300px"
              />
                </div>
                <div>
                  <div className='d-flex'>
                    <div className='p-2'>
                     <p> car Name</p>
                      </div>
                      <div className='p-2'>
                      <p>{car.carName}</p>
                      </div>
                    </div>
                    <div className='d-flex'>
                    <div className='p-2'>
                      <p>car Company</p>
                      </div>
                      <div className='p-2'>
                      <p>{car.carCompany}</p>
                      </div>
                    </div>
                    <div className='d-flex'>
                    <div className='p-2' >
                     <p> Fuel Type</p>
                      </div>
                      <div className='p-2' >
                      <p>{car.fuelType}</p>
                      </div>
                    </div>
                  </div>
              
              
              </div>
            
           
          
          </div>
    </div>

        


            
        
         
      </div>
         


  )

})}
</div>
</div>
  )
}
export default Home