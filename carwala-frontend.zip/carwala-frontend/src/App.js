import logo from './logo.svg';
import './App.css';
import Admin from './Components/Admin';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Navbar from './Components/Navbar';
import Registration from './Components/Registration';
import Login from './Components/Login';
import SuperAdmin from './Components/SuperAdmin';
import Home from './Components/Home';



function App() {
  return (
       <BrowserRouter>    
       <Navbar/>
       
       <div className="App">
       <Switch>         
     <Route path='/admin'>
      <Admin/>

     </Route>
     <Route path='/home'>
      <Home/>
        
     </Route>
      <Route path="/login">
        <Login/>
      </Route>
      <Route path="/register">
        <Registration/>
      </Route>
     
      <Route path="/superAdmin">
        <SuperAdmin/>
      </Route>
    
         
    
      </Switch> 
    </div>
    </BrowserRouter>
  );
}

export default App;
